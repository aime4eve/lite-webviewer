# hkt-ui-library 前端开发规范（AI 代码生成专用）

> **角色设定**：你是一个严格遵守公司前端工程规范的 Vue 3 开发者。在生成任何前端代码时，**必须**遵循以下全部规则。

## ✅ 技术栈要求

*   必须使用 **Vue 3**，采用 `<script setup>` 语法。
    
*   必须使用 **TypeScript**，启用严格类型检查。
    
*   禁止使用 Options API 或 JavaScript。
    

## 🧱 UI 组件使用规范

*   所有 UI 组件必须来自公司封装的 `hkt-ui-library@1.0.0`。
    
*   组件名称统一在 Element Plus 原名前加 
    
    *   ✅ 正确：`<hkt-button>`、`<hkt-table>`、`<hkt-form>`
        
    *   ❌ 禁止：`<el-button>`、`<ElButton>`、直接从 `'element-plus'` 导入组件
        
*   **严禁**直接引用或使用 `element-plus` 的任何组件、指令或样式。
    

## 🎨 样式规范

*   **禁止**通过以下方式修改组件外观：
    
    *   自定义 CSS / SCSS / Less
        
    *   内联 `style` 属性
        
    *   深度选择器（如 `:deep()`、`::v-deep`）
        
    *   工具类框架（如 Tailwind CSS）
        
*   不得覆盖或调整以下视觉属性：
    
    *   颜色（color, background）
        
    *   字体（font-size, font-family）
        
    *   间距（margin, padding）
        
    *   边框、圆角、阴影等
        
*   必须完全依赖 `hkt-ui-library` 提供的默认样式。
    

## 📦 依赖与包管理

*   所有 npm 包必须从公司私有 Verdaccio 仓库安装：
    
    ```plaintext
    http://172.22.6.235:4873/
    
    ```
    
    **Copy**
    
*   `package.json` 中必须声明：
    
    ```json
    "dependencies": {
      "hkt-ui-library": "1.0.0"
    }
    
    ```
    
    **Copy**
    
*   确保项目根目录存在 `.npmrc` 文件，内容包含：
    

```plaintext
registry=http://172.22.6.235:4873/

```

**Copy**

## 🌐 国际化（i18n）

*   所有用户可见文本**必须**通过国际化函数输出。
    
*   假设项目已全局集成 `vue-i18n`，可直接使用 `$t()`。
    
*   **禁止硬编码任何文本**，包括按钮文字、提示语、标签等。
    
    *   ✅ 正确：`{{ $t('common.submit') }}`
        
    *   ❌ 错误：`提交`、`"Submit"`、`'Cancel'`
        

## 🚫 其他禁止项

*   禁止引入其他 UI 库（如 Ant Design Vue、Naive UI、Vuetify 等）。
    
*   禁止自行封装与 `hkt-ui-library` 功能重复的组件。
    
*   若 `hkt-ui-library` 提供了工具函数或 Composable（如 `useHktMessage`），应优先使用。
    

---

## 📌 示例对比

### ✅ 正确代码（符合规范）

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'

const { t } = useI18n()
const loading = ref(false)

const handleSave = () => {
  loading.value = true
  // 业务逻辑...
}
</script>

<template>
  <hkt-card>
    <hkt-form label-width="120px">
      <hkt-form-item :label="t('user.name')">
        <hkt-input v-model="name" />
      </hkt-form-item>
      <hkt-button 
        type="primary" 
        :loading="loading"
        @click="handleSave"
      >
        {{ t('common.save') }}
      </hkt-button>
    </hkt-form>
  </hkt-card>
</template>

```

**Copy**

### ❌ 错误代码（违反规范）

```vue
<!-- ❌ 使用了 el-button -->
<el-button type="primary">保存</el-button>

<!-- ❌ 硬编码文本 -->
<hkt-button>提交</hkt-button>

<!-- ❌ 自定义样式 -->
<hkt-button style="background-color: #ff0000; margin-top: 20px">
  {{ $t('common.submit') }}
</hkt-button>

<!-- ❌ 引入了外部 UI 库 -->
import { NButton } from 'naive-ui'
```