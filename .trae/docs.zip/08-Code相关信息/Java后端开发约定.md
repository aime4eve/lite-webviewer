# Java后端开发规范与约定

## 版本与修订记录

| 版本 |    日期    |  作者  | 修订说明 |
| ---- | ---------- | ------ | -------- |
| 1.0  | 2025-12-18 | 毛远波 | 初始版本 |

---

## 一、编码规范与开发约束

### 1.1 开发工具与代码检查
- **Alibaba Java Coding Guidelines插件**：所有Java开发人员必须安装并使用该插件检查代码，提交前应消除所有警告。
- **禁止调试代码残留**：提交的代码中不得包含用于本地测试的`Main`方法、`System.out.print`语句，异常信息禁止使用`printStackTrace()`打印。
- **禁止忽略警告**：不允许使用`@SuppressWarnings`注解，应通过重构解决警告问题。
- **重复代码处理**：有重复代码必须提取封装，保持DRY原则。

### 1.2 数据类型与集合处理

#### 1.2.1 包装类型与原始类型使用规范
- **POJO/DTO/VO字段定义**：所有实体类字段必须使用包装类型（`Integer`、`Long`、`Boolean`等），禁止使用原始类型（`int`、`long`、`boolean`等），以支持null值判断。
  
  ```java
  // ✅ 正确
  public class UserDTO {
      private Integer id;
      private String name;
      private Boolean active;  // 支持null，表示"未知"
  }
  
  // ❌ 错误
  public class UserDTO {
      private int id;          // 默认值为0，无法区分空值
      private boolean active;  // 默认值为false，无法区分"未激活"和"未知"
  }
  ```

- **方法参数与返回值**：
  - 对外暴露的API接口（Controller、Service接口）必须使用包装类型
  - 内部工具类方法可根据场景使用原始类型以提高性能
  
  ```java
  // ✅ 对外接口使用包装类型
  public interface UserService {
      UserDTO getUserById(Integer id);  // id可为null
      List<UserDTO> findUsersByStatus(Boolean active);  // active可为null表示查询全部
  }
  
  // ✅ 内部工具方法可适当使用原始类型
  public class MathUtils {
      public static int add(int a, int b) {  // 纯计算，参数不会为null
          return a + b;
      }
  }
  ```

- **数据库映射字段**：
  - Mybatis实体类（PO）必须使用包装类型
  - 查询结果中可能为null的字段必须使用包装类型
  
- **空指针防护**：
  ```java
  // ❌ 危险：自动拆箱可能NPE
  public void process(Integer count) {
      int num = count;  // 如果count为null，此处抛出NullPointerException
  }
  
  // ✅ 安全：显式判空
  public void process(Integer count) {
      if (count == null) {
          count = 0;  // 或抛出业务异常
      }
      int num = count;
  }
  ```

#### 1.2.2 浮点数使用限制
- 尽量避免使用`double`、`float`，除非第三方SDK明确要求。
- 金额、精度计算必须使用`BigDecimal`。

#### 1.2.3 集合处理规范
- **集合返回规范**：集合为空时应返回空集合（如`Collections.emptyList()`、`emptyMap()`、`emptySet()`），禁止返回`null`。
- **Map使用限制**：`public`方法禁止使用`Map`作为参数或返回值（特殊场景需审批）。
- **枚举设计**：枚举常量值不建议使用`0`（尤其是`int`类型）。
- **拼写检查**：所有英文单词应拼写正确，IDEA中标记的绿色波浪线应修正（专有名词除外）。

### 1.3 流程控制与资源管理
- **循环控制语句**：流程控制语句中禁止出现两个及以上`break`或`continue`，应考虑重构。
- **资源释放**：IO流、数据库连接等资源必须使用`try-with-resources`确保释放。
- **Lambda与Stream**：避免过度复杂的Lambda表达式和Stream操作，简单的排序、过滤、映射可以使用。

### 1.4 SQL与数据库操作规范

#### 1.4.1 通用SQL规范
- **禁止SQL魔法值**：所有查询条件值必须通过参数传递，禁止在SQL中硬编码（如`status = 1`）。
- **避免SQL函数与类型转换**：尽量避免在SQL中使用函数或进行类型转换，应在业务层处理。
- **分页查询实现**：多表关联分页查询应自行实现`COUNT`与`LIMIT`，避免直接使用MyBatis分页插件。
- **循环查询禁止**：禁止在循环中执行数据库查询，应合并查询或使用批量操作。
- **查询返回字段**：查询返回字段不应在SQL中进行类型转换或计算。

#### 1.4.2 存储过程使用约束
- **基本原则**：新功能开发禁止使用存储过程，存量存储过程应逐步迁移到应用层。
- **允许使用场景**（需技术负责人审批）：
  1. 复杂的报表统计查询（性能要求极高）
  2. 数据库层面的数据迁移、清洗任务
  3. 第三方系统强依赖的存储过程
  
- **存储过程开发规范**：
  ```sql
  -- ✅ 规范示例
  CREATE PROCEDURE sp_calculate_monthly_report(
      IN p_year INT,           -- 参数前缀p_
      IN p_month INT,
      OUT o_total DECIMAL(18,2) -- 输出参数前缀o_
  )
  BEGIN
      -- 必须有明确的注释说明
      /* 
       * 功能：计算月度报表
       * 作者：张三
       * 创建时间：2024-01-15
       * 修改记录：
       *   2024-02-01 李四：增加异常处理
       */
      
      -- 必须有异常处理
      DECLARE EXIT HANDLER FOR SQLEXCEPTION
      BEGIN
          ROLLBACK;
          SET o_total = -1;  -- 使用特殊值标识失败
          -- 必须记录错误日志
          INSERT INTO sp_error_log(proc_name, error_msg, create_time)
          VALUES('sp_calculate_monthly_report', SQLERRM, NOW());
      END;
      
      -- 事务必须明确控制
      START TRANSACTION;
      
      -- 业务逻辑...
      
      COMMIT;
  END;
  ```

- **Mybatis调用存储过程规范**：
  ```xml
  <!-- ✅ 正确调用方式 -->
  <select id="callMonthlyReport" statementType="CALLABLE">
      {call sp_calculate_monthly_report(
          #{year, mode=IN, jdbcType=INTEGER},
          #{month, mode=IN, jdbcType=INTEGER},
          #{total, mode=OUT, jdbcType=DECIMAL}
      )}
  </select>
  ```
  
  ```java
  // Service层调用
  public BigDecimal calculateMonthlyReport(int year, int month) {
      Map<String, Object> params = new HashMap<>();
      params.put("year", year);
      params.put("month", month);
      params.put("total", null);  // 输出参数初始化为null
      
      mapper.callMonthlyReport(params);
      
      BigDecimal result = (BigDecimal) params.get("total");
      if (result == null || result.compareTo(BigDecimal.ZERO) < 0) {
          throw new BusinessException("报表计算失败");
      }
      return result;
  }
  ```

- **存储过程维护要求**：
  1. 必须纳入版本控制系统（Git）
  2. 必须有完整的单元测试
  3. 必须有详细的技术文档，包括：
     - 功能说明
     - 参数说明
     - 返回结果说明
     - 性能影响分析
  4. 变更必须经过DBA审核

### 1.5 业务逻辑与分层规范
- **Service方法设计**：方法命名应具有业务含义，避免因过度复用导致参数过多、语义不清。
- **状态枚举值固定**：涉及数据库更新的操作，状态枚举值应在Service中固定，禁止从前端传入。
- **异常与日志**：抛出业务异常或系统异常时必须记录日志（使用Logback），日志应包含关键业务参数（如用户ID、操作类型、数据标识等）。
- **参数校验分层**：
  - 基础格式校验：Controller层处理
  - 业务逻辑校验：Service层处理
- **实体分层**：Controller返回给前端的对象（VO/DTO）与Service层实体（BO/PO）必须分离。

### 1.6 API接口设计规范
- **URI命名规范**：使用`/`分隔单词，禁止使用驼峰命名，URI中单词不得重复。
- **返回数据结构**：API返回的`data`字段应统一为对象或`Map`结构，禁止直接返回数组、列表、字符串、数字等原始类型。
- **空值返回一致性**：`data`字段无论有无值都应保持结构一致。

---

## 二、单元测试规范（TestNG + AssertJ）

### 2.1 单元测试基本原则
- **测试覆盖要求**：核心业务逻辑、复杂算法、边界条件必须编写单元测试
- **测试代码质量**：测试代码与生产代码同等重要，需遵循相同的编码规范
- **测试独立性**：每个测试用例必须相互独立，不依赖执行顺序
- **测试命名规范**：测试类名使用`被测试类名 + Test`，测试方法名使用`test + 被测试方法名 + 测试场景`

### 2.2 依赖配置
```xml
<!-- pom.xml 依赖 -->
<dependency>
    <groupId>org.testng</groupId>
    <artifactId>testng</artifactId>
    <version>7.7.1</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>org.assertj</groupId>
    <artifactId>assertj-core</artifactId>
    <version>3.24.2</version>
    <scope>test</scope>
</dependency>
```

### 2.3 断言库规范
**项目统一使用AssertJ作为唯一断言库**，禁止使用TestNG原生Assert或其他断言库。

```java
// ✅ 正确导入方式
import static org.assertj.core.api.Assertions.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.catchThrowable;

// ❌ 禁止导入
import static org.testng.Assert.*;  // 禁止使用
import org.junit.Assert;             // 禁止使用
```

### 2.4 AssertJ 使用规范

#### 2.4.1 基础断言
```java
public class BasicAssertionsTest {
    
    @Test
    public void testStringAssertions() {
        String name = "John";
        assertThat(name)
            .isEqualTo("John")
            .isNotEqualTo("Jane")
            .contains("oh")
            .startsWith("J")
            .hasSize(4);
    }
    
    @Test
    public void testNumberAssertions() {
        Integer age = 25;
        assertThat(age)
            .isEqualTo(25)
            .isBetween(18, 60)
            .isGreaterThan(18)
            .isPositive()
            .isNotZero();
    }
    
    @Test
    public void testBooleanAssertions() {
        Boolean isActive = true;
        assertThat(isActive).isTrue();
        
        Boolean nullableFlag = null;
        assertThat(nullableFlag).isNull();
    }
    
    @Test
    public void testCollectionAssertions() {
        List<String> names = Arrays.asList("John", "Jane", "Bob");
        assertThat(names)
            .hasSize(3)
            .contains("John", "Bob")
            .doesNotContain("Alice")
            .containsExactlyInAnyOrder("Bob", "Jane", "John")
            .allSatisfy(name -> assertThat(name).hasSizeGreaterThan(2));
        
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Math", 90);
        scores.put("English", 85);
        assertThat(scores)
            .hasSize(2)
            .containsKey("Math")
            .containsValue(90)
            .containsEntry("English", 85);
    }
}
```

#### 2.4.2 对象断言
```java
public class ObjectAssertionsTest {
    
    @Test
    public void testObjectProperties() {
        User user = new User(1, "John", "john@example.com", 25);
        
        // 提取多个属性
        assertThat(user)
            .extracting("id", "name", "email", "age")
            .containsExactly(1, "John", "john@example.com", 25);
        
        // 提取单个属性
        assertThat(user)
            .extracting(User::getName, User::getEmail)
            .containsExactly("John", "john@example.com");
        
        // 使用satisfy进行复杂验证
        assertThat(user).satisfies(u -> {
            assertThat(u.getId()).isEqualTo(1);
            assertThat(u.getName()).startsWith("J");
            assertThat(u.getAge()).isBetween(18, 60);
        });
    }
    
    @Test
    public void testObjectComparison() {
        User user1 = new User(1, "John", "john@example.com");
        User user2 = new User(1, "John", "john@example.com");
        User user3 = new User(2, "Jane", "jane@example.com");
        
        assertThat(user1).isEqualTo(user2);  // 需要正确实现equals方法
        assertThat(user1).isNotEqualTo(user3);
        
        // 使用usingRecursiveComparison进行深度比较
        assertThat(user1)
            .usingRecursiveComparison()
            .ignoringFields("createTime")  // 忽略时间字段
            .isEqualTo(user2);
    }
}
```

#### 2.4.3 异常断言
```java
public class ExceptionAssertionsTest {
    
    @Test
    public void testExceptionThrown() {
        // 方式1：推荐使用assertThatThrownBy
        assertThatThrownBy(() -> {
            userService.getUserById(null);
        })
        .isInstanceOf(IllegalArgumentException.class)
        .hasMessage("用户ID不能为空")
        .hasMessageContaining("用户ID")
        .hasNoCause();  // 验证没有嵌套异常
        
        // 方式2：使用catchThrowable捕获异常
        Throwable thrown = catchThrowable(() -> {
            userService.getUserById(null);
        });
        
        assertThat(thrown)
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessageStartingWith("用户ID");
    }
    
    @Test
    public void testNoExceptionThrown() {
        // 验证没有异常抛出
        assertThatNoException()
            .isThrownBy(() -> {
                userService.getUserById(1);
            });
    }
}
```

#### 2.4.4 包装类型安全断言
```java
public class WrapperTypeAssertionsTest {
    
    @Test
    public void testNullSafety() {
        // 安全处理包装类型
        Integer nullableValue = getUserScore();
        
        // 必须先判空
        assertThat(nullableValue)
            .as("用户分数检查")
            .isNotNull()
            .isGreaterThan(0)
            .isLessThanOrEqualTo(100);
        
        // 链式断言确保安全
        assertThat(getUser())
            .as("用户信息")
            .isNotNull()
            .extracting(User::getId, User::getAge)
            .as("用户ID和年龄")
            .doesNotContainNull();
    }
    
    @Test
    public void testOptionalAssertions() {
        Optional<String> optionalValue = findUserName();
        
        assertThat(optionalValue)
            .isPresent()
            .contains("John")
            .hasValueSatisfying(name -> 
                assertThat(name).hasSize(4));
        
        Optional<String> emptyOptional = Optional.empty();
        assertThat(emptyOptional).isEmpty();
    }
}
```

### 2.5 TestNG使用规范
```java
import org.testng.annotations.*;
import static org.assertj.core.api.Assertions.*;

public class UserServiceTest {
    
    @BeforeClass
    public void setUpClass() {
        // 类级别初始化
    }
    
    @AfterClass
    public void tearDownClass() {
        // 类级别清理
    }
    
    @BeforeMethod
    public void setUp() {
        // 每个测试方法前执行，准备测试数据
    }
    
    @AfterMethod
    public void tearDown() {
        // 每个测试方法后执行，清理测试数据
    }
    
    @Test(description = "测试用户创建-正常场景")
    public void testCreateUser_success() {
        // Arrange
        UserCreateRequest request = UserCreateRequest.builder()
            .name("张三")
            .email("zhangsan@example.com")
            .age(25)
            .build();
        
        // Act
        UserDTO result = userService.createUser(request);
        
        // Assert - 统一使用AssertJ
        assertThat(result)
            .as("用户创建结果")
            .isNotNull()
            .extracting(UserDTO::getId, UserDTO::getName, UserDTO::getAge)
            .containsExactly(null, "张三", 25);  // ID由数据库生成
        
        assertThat(result.getId())
            .as("生成的用户ID")
            .isNotNull()
            .isPositive();
    }
    
    @Test(description = "测试用户创建-参数验证")
    public void testCreateUser_invalidName() {
        UserCreateRequest request = UserCreateRequest.builder()
            .name("")  // 空用户名
            .email("test@example.com")
            .build();
        
        assertThatThrownBy(() -> userService.createUser(request))
            .as("空用户名应该抛出异常")
            .isInstanceOf(BusinessException.class)
            .hasMessageContaining("用户名")
            .hasMessageContaining("不能为空");
    }
    
    @DataProvider(name = "ageTestData")
    public Object[][] provideAgeTestData() {
        return new Object[][] {
            {17, false, "未成年"},
            {18, true, "刚好成年"},
            {30, true, "正常成年"},
            {null, false, "年龄为空"}  // 测试包装类型null值
        };
    }
    
    @Test(description = "测试年龄验证", 
          dataProvider = "ageTestData")
    public void testValidateUserAge(Integer age, boolean expected, String caseDesc) {
        // Act
        boolean result = userService.isAdult(age);
        
        // Assert
        assertThat(result)
            .as("年龄验证测试: %s", caseDesc)
            .isEqualTo(expected);
    }
}
```

### 2.6 软断言使用规范
```java
public class SoftAssertionsTest {
    
    @Test
    public void testMultipleAssertions() {
        // 使用SoftAssertions进行多个独立断言
        SoftAssertions softly = new SoftAssertions();
        
        User user = userService.getUserById(1);
        
        softly.assertThat(user)
            .as("用户基本信息")
            .isNotNull();
        
        softly.assertThat(user.getName())
            .as("用户姓名")
            .isNotBlank()
            .hasSizeBetween(2, 20);
        
        softly.assertThat(user.getEmail())
            .as("用户邮箱")
            .contains("@")
            .doesNotContain(" ");
        
        softly.assertThat(user.getAge())
            .as("用户年龄")
            .isNotNull()
            .isBetween(0, 150);
        
        // 收集所有断言结果
        softly.assertAll();
    }
}
```

### 2.7 自定义断言工具类
```java
/**
 * 业务断言工具类 - 统一使用AssertJ实现
 */
public final class BusinessAssertions {
    
    private BusinessAssertions() {
        // 工具类禁止实例化
    }
    
    public static void assertValidUserId(Integer userId) {
        assertThat(userId)
            .as("用户ID必须有效")
            .isNotNull()
            .isGreaterThan(0);
    }
    
    public static void assertUserActive(User user) {
        assertThat(user)
            .as("用户必须存在且活跃")
            .isNotNull()
            .extracting(User::getStatus, User::isEnabled)
            .as("用户状态")
            .containsExactly(UserStatus.ACTIVE, true);
    }
    
    public static void assertSuccessResponse(R<?> response) {
        assertThat(response)
            .as("API响应必须成功")
            .isNotNull()
            .extracting(R::getCode, R::isSuccess, R::getMsg)
            .as("响应码、成功标志、消息")
            .containsExactly(200, true, "操作成功");
    }
    
    public static void assertPageResult(Page<?> page) {
        assertThat(page)
            .as("分页结果必须有效")
            .isNotNull()
            .extracting(Page::getRecords, Page::getTotal, Page::getSize)
            .as("记录列表、总数、页大小")
            .doesNotContainNull();
        
        assertThat(page.getTotal())
            .as("总记录数")
            .isGreaterThanOrEqualTo(0);
    }
}

// 使用示例
@Test
public void testWithBusinessAssertions() {
    User user = userService.getUserById(1);
    
    BusinessAssertions.assertValidUserId(user.getId());
    BusinessAssertions.assertUserActive(user);
    
    R<UserVO> response = userController.getUser(1);
    BusinessAssertions.assertSuccessResponse(response);
}
```

### 2.8 测试覆盖率要求
- **行覆盖率**：核心业务类不低于80%
- **分支覆盖率**：复杂逻辑分支必须全部覆盖
- **异常路径测试**：所有异常处理逻辑必须编写测试用例
- **边界条件测试**：必须测试边界值、空值、极限值等场景
- **包装类型测试**：必须测试null值场景

### 2.9 测试代码组织规范
```
src/test/java/
├── com/company/module/          # 单元测试目录结构与生产代码保持一致
│   ├── service/
│   │   ├── UserServiceTest.java
│   │   └── OrderServiceTest.java
│   ├── controller/
│   │   └── UserControllerTest.java
│   └── dao/
│       ├── UserDaoTest.java
│       └── procedure/           # 存储过程相关测试
│           └── ReportProcedureTest.java
└── resources/
    ├── test-data.sql           # 测试数据SQL
    ├── stored-procedures/      # 测试用存储过程
    │   └── sp_test_report.sql
    ├── application-test.yml    # 测试配置文件
    └── logback-test.xml        # 测试日志配置
```

---

## 三、RESTful API设计与响应规范

### 3.1 统一响应结构
所有Controller应返回`com.hkt.core.tool.api.R<T>`类型：

```java
// 返回数据对象
public R<UserVO> getUserById(@PathVariable String id) {
    return R.data(userVO);
}

// 无数据返回
public R<Void> deleteUser(@PathVariable String id) {
    return R.success();
}

// 分页查询返回
public R<Page<UserVO>> pageUsers(@Validated UserQueryParam param) {
    return R.data(page);
}
```

**响应格式：**
```json
{
  "code": 200,
  "success": true,
  "msg": "操作成功",
  "data": {}
}
```

### 3.2 HTTP方法使用约定
| 方法   | 用途           | 示例路径             | 说明 |
|--------|----------------|----------------------|------|
| GET    | 获取资源       | `/users/{id}`        | 查询单条 |
| GET    | 分页查询       | `/users/page`        | 分页列表 |
| GET    | 查询子资源     | `/users/{id}/orders` | 关联查询 |
| POST   | 创建资源       | `/users`             | 新增 |
| PUT    | 更新资源       | `/users/{id}`        | 全量更新 |
| PATCH  | 部分更新       | `/users/{id}`        | 部分更新（可选） |
| DELETE | 删除资源       | `/users/{id}`        | 删除 |

### 3.3 错误码定义规范
错误码应实现`IResultCode`接口，按业务模块定义枚举类：

```java
@Getter
@AllArgsConstructor
public enum UserResultCode implements IResultCode {
    USER_NOT_FOUND(404, "user.not.found", "用户不存在"),
    USER_DISABLED(403, "user.disabled", "用户已被禁用"),
    USER_PASSWORD_ERROR(400, "user.password.error", "密码错误");

    private final int code;
    private final String i18nMessageKey;
    private final String message;
}
```

---

## 四、Swagger接口文档规范

### 4.1 必需注解
所有Controller类及其方法必须使用以下Swagger注解：

|                          注解                           |   使用位置    |          说明           |
| ------------------------------------------------------- | ------------ | ---------------------- |
| `@Tag(name = "模块名称")`                               | Controller类 | 模块分类                |
| `@Operation(summary = "接口说明")`                      | 接口方法      | 功能描述                |
| `@Parameters`                                           | 接口方法      | 参数列表                |
| `@Parameter(value = "参数说明", required = true/false)` | 方法参数      | 参数说明, @Parameters里 |

---

## 五、数据库与Mybatis规范补充

### 5.1 表设计规范
- 表字段应选择合适的数据库类型和长度
- 时间字段统一使用`datetime`或`timestamp`，并明确时区处理策略
- 枚举字段建议使用`tinyint`或`varchar`，并建立字典表或枚举类映射

### 5.2 Mybatis使用规范
- XML中禁止使用`${}`进行字符串拼接（SQL注入风险）
- 使用`<if test="...">`进行动态SQL条件判断
- 结果映射使用`<resultMap>`，避免`resultType="map"`
- 批量操作使用`<foreach>`标签

---

## 六、多时区与国际化支持

### 6.1 参考文档
- 《国际化整体方案设计.md》 - 整体架构设计
- 《国际化方案日期设计.md》 - 日期时间处理规范
- 《国际化数据库存储设计.md》 - 数据库存储规范

### 6.2 核心原则
1. 所有时间存储使用UTC时区
2. 前端展示时根据用户时区转换
3. 多语言文案使用统一的i18n消息键
4. 错误码包含i18n消息键（见3.3节）

---

## 七、附录：代码质量检查清单

### 提交前必须检查：
- [ ] Alibaba插件无警告
- [ ] 单元测试通过率100%
- [ ] 核心业务代码覆盖率≥80%
- [ ] 无调试代码残留
- [ ] 集合返回非null
- [ ] SQL无魔法值
- [ ] 日志包含关键参数
- [ ] 实体分层清晰
- [ ] API路径规范
- [ ] 错误码使用正确
- [ ] Swagger注解完整
- [ ] 英文单词拼写正确

### 单元测试专项检查：
- [ ] 使用AssertJ断言，禁止使用TestNG/JUnit原生Assert
- [ ] 测试用例包含正常场景
- [ ] 测试用例包含异常场景
- [ ] 测试用例包含边界条件
- [ ] 使用@DataProvider进行参数化测试
- [ ] Mock对象使用规范
- [ ] 测试数据清理完整
- [ ] 断言信息明确（使用.as()添加描述）
- [ ] 包装类型null值测试完整
- [ ] 测试执行时间合理（单个用例<1秒）

### 包装类型专项检查：
- [ ] POJO/DTO字段使用包装类型
- [ ] Service接口参数使用包装类型
- [ ] 数据库映射字段使用包装类型
- [ ] 所有包装类型都进行了null安全处理
- [ ] 禁止自动拆箱导致的NPE风险

### 存储过程专项检查：
- [ ] 新功能禁止使用存储过程
- [ ] 存量存储过程有审批记录
- [ ] 存储过程有完整文档
- [ ] 存储过程有单元测试
- [ ] 存储过程调用有异常处理

---

**文档说明：**
- 本规范在《阿里Java编程规范》基础上补充制定
- 所有开发人员必须遵守
- 规范将随技术演进定期更新
- 单元测试是代码提交的强制要求，未通过测试的代码不得合并
- 如有疑问或建议，请联系技术架构组
