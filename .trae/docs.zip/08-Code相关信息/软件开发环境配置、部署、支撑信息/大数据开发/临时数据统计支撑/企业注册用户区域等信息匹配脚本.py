import pandas as pd
import pymysql
from sqlalchemy import create_engine
import logging
from tqdm import tqdm

# 设置日志和进度条
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def fill_company_data():
    # 1. 读取Excel文件
    logger.info("正在读取Excel文件...")
    df_excel = pd.read_excel('D:\\software\\Nwt_cache_recv\\刘玉梅\\注册用户数据导出.xls', skiprows=1)
    logger.info(f"成功读取 {len(df_excel)} 条数据")

    # 特别检查目标企业
    target_company = "长沙蓉湘文化传播有限公司"
    target_rows = df_excel[df_excel['企业名称'] == target_company]
    if not target_rows.empty:
        logger.info(f"找到目标企业 '{target_company}' 在Excel中")
        for idx, row in target_rows.iterrows():
            logger.info(f"  信用代码: {row['用户登录名']}")

    # 2. 连接MySQL数据库
    logger.info("正在连接数据库...")
    connection = pymysql.connect(
        host='172.22.1.19',
        user='bigdata',
        password='Bigdata123!@#',
        database='hkt_company',
        charset='utf8mb4'
    )

    # 3. 定义查询模板
    query_by_credit_code = """
    SELECT 
        a.UNISCID as '企业信用代码',
        a.ENTNAME as '企业名称',
        b.ENTSTATUS_CN as '经营状态',
        SUBSTR(d.fulltitle,7) as '区县',
        CASE 
            WHEN EXISTS (
                SELECT 1 FROM hkt_company.company_modify cm 
                WHERE cm.entid = a.entid 
                AND cm.ALTDATE BETWEEN '2025-01-01' AND '2025-11-07'
            ) THEN '有'
            ELSE '无'
        END as '近期是否有工商变更',
        COALESCE((
            SELECT GROUP_CONCAT(CONCAT(cm.ALTDATE, ':', cm.ALTITEM) SEPARATOR '; ')
            FROM (
                SELECT cm.ALTDATE, cm.ALTITEM
                FROM hkt_company.company_modify cm 
                WHERE cm.entid = a.entid 
                AND cm.ALTDATE BETWEEN '2025-01-01' AND '2025-11-07'
                ORDER BY cm.ALTDATE DESC
                LIMIT 5
            ) cm
        ), '') as '变更事项'
    FROM hkt_company.company a
    LEFT JOIN hkt_company.company_basic b ON a.entid = b.entid
    LEFT JOIN hkt_company.company_class c ON a.entid = c.entid 
    LEFT JOIN hkt_code.code_region d ON c.region_id = d.code
    WHERE a.UNISCID = %s
    """

    query_by_company_name = """
    SELECT 
        a.UNISCID as '企业信用代码',
        a.ENTNAME as '企业名称',
        b.ENTSTATUS_CN as '经营状态',
        SUBSTR(d.fulltitle,7) as '区县',
        CASE 
            WHEN EXISTS (
                SELECT 1 FROM hkt_company.company_modify cm 
                WHERE cm.entid = a.entid 
                AND cm.ALTDATE BETWEEN '2025-01-01' AND '2025-11-07'
            ) THEN '有'
            ELSE '无'
        END as '近期是否有工商变更',
        COALESCE((
            SELECT GROUP_CONCAT(CONCAT(cm.ALTDATE, ':', cm.ALTITEM) SEPARATOR '; ')
            FROM (
                SELECT cm.ALTDATE, cm.ALTITEM
                FROM hkt_company.company_modify cm 
                WHERE cm.entid = a.entid 
                AND cm.ALTDATE BETWEEN '2025-01-01' AND '2025-11-07'
                ORDER BY cm.ALTDATE DESC
                LIMIT 5
            ) cm
        ), '') as '变更事项'
    FROM hkt_company.company a
    LEFT JOIN hkt_company.company_basic b ON a.entid = b.entid
    LEFT JOIN hkt_company.company_class c ON a.entid = c.entid 
    LEFT JOIN hkt_code.code_region d ON c.region_id = d.code
    WHERE a.ENTNAME = %s
    """

    # 4. 创建结果DataFrame
    df_final = df_excel.copy()

    # 初始化要填充的列
    df_final['经营状态'] = '未知'
    df_final['所属区域'] = '未知'
    df_final['近期是否有工商变更'] = '无'
    df_final['变更事项'] = ''
    df_final['匹配方式'] = '未匹配'

    # 5. 逐行查询并匹配
    credit_code_matched = 0
    company_name_matched = 0
    not_matched = 0

    with connection.cursor() as cursor:
        cursor.execute("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci")

        for idx, row in tqdm(df_final.iterrows(), total=len(df_final), desc="逐行查询匹配"):
            credit_code = str(row['用户登录名']).strip() if pd.notna(row['用户登录名']) and row[
                '用户登录名'] != '' else None
            company_name = str(row['企业名称']).strip() if pd.notna(row['企业名称']) and row['企业名称'] != '' else None

            matched = False
            match_method = '未匹配'

            # 调试目标企业
            is_target = company_name == target_company

            # 第一步：优先使用信用代码查询
            if credit_code:
                try:
                    cursor.execute(query_by_credit_code, (credit_code,))
                    result = cursor.fetchone()

                    if result:
                        # 使用信用代码匹配成功
                        df_final.at[idx, '经营状态'] = result[2] if result[2] and result[2] != '' else '未知'
                        df_final.at[idx, '所属区域'] = result[3] if result[3] and result[3] != '' else '未知'
                        df_final.at[idx, '近期是否有工商变更'] = result[4] if result[4] and result[4] != '' else '无'
                        df_final.at[idx, '变更事项'] = result[5] if result[5] else ''
                        df_final.at[idx, '匹配方式'] = '信用代码匹配'
                        credit_code_matched += 1
                        matched = True
                        match_method = '信用代码匹配'

                        if is_target:
                            logger.info(f"目标企业 '{target_company}' 通过信用代码匹配成功")
                            logger.info(f"  经营状态: {result[2]}")
                            logger.info(f"  所属区域: {result[3]}")
                            logger.info(f"  工商变更: {result[4]}")

                except Exception as e:
                    if is_target:
                        logger.warning(f"目标企业信用代码查询失败: {credit_code}, 错误: {e}")

            # 第二步：如果信用代码未匹配成功，使用企业名称查询
            if not matched and company_name:
                try:
                    cursor.execute(query_by_company_name, (company_name,))
                    result = cursor.fetchone()

                    if result:
                        # 使用企业名称匹配成功
                        df_final.at[idx, '经营状态'] = result[2] if result[2] and result[2] != '' else '未知'
                        df_final.at[idx, '所属区域'] = result[3] if result[3] and result[3] != '' else '未知'
                        df_final.at[idx, '近期是否有工商变更'] = result[4] if result[4] and result[4] != '' else '无'
                        df_final.at[idx, '变更事项'] = result[5] if result[5] else ''
                        df_final.at[idx, '匹配方式'] = '企业名称匹配'
                        company_name_matched += 1
                        matched = True
                        match_method = '企业名称匹配'

                        if is_target:
                            logger.info(f"目标企业 '{target_company}' 通过企业名称匹配成功")
                            logger.info(f"  经营状态: {result[2]}")
                            logger.info(f"  所属区域: {result[3]}")
                            logger.info(f"  工商变更: {result[4]}")
                            logger.info(f"  数据库中的信用代码: {result[0]}")
                            logger.info(f"  数据库中的企业名称: {result[1]}")

                except Exception as e:
                    if is_target:
                        logger.warning(f"目标企业名称查询失败: {company_name}, 错误: {e}")

            if not matched:
                not_matched += 1
                if is_target:
                    logger.warning(f"目标企业 '{target_company}' 完全匹配失败")
                    # 调试：检查查询参数
                    logger.info(f"  使用的信用代码: {credit_code}")
                    logger.info(f"  使用的企业名称: {company_name}")

    connection.close()

    # 6. 特别检查目标企业的最终结果
    target_final = df_final[df_final['企业名称'] == target_company]
    if not target_final.empty:
        logger.info(f"=== 目标企业 '{target_company}' 最终匹配结果 ===")
        for idx, target_row in target_final.iterrows():
            logger.info(f"  信用代码: {target_row['用户登录名']}")
            logger.info(f"  经营状态: {target_row['经营状态']}")
            logger.info(f"  所属区域: {target_row['所属区域']}")
            logger.info(f"  工商变更: {target_row['近期是否有工商变更']}")
            logger.info(f"  匹配方式: {target_row['匹配方式']}")

    # 7. 输出详细统计
    logger.info("=== 详细匹配统计 ===")
    logger.info(f"信用代码匹配成功: {credit_code_matched} 条")
    logger.info(f"企业名称匹配成功: {company_name_matched} 条")
    logger.info(f"未匹配: {not_matched} 条")
    logger.info(f"总记录数: {len(df_final)} 条")
    logger.info(f"总匹配率: {(credit_code_matched + company_name_matched) / len(df_final) * 100:.2f}%")

    # 8. 按匹配方式统计
    match_method_counts = df_final['匹配方式'].value_counts()
    logger.info("匹配方式分布:")
    for method, count in match_method_counts.items():
        percentage = count / len(df_final) * 100
        logger.info(f"  {method}: {count} ({percentage:.2f}%)")

    # 9. 保存结果
    output_columns = ['用户登录名', '企业名称', '手机号', '用户类型', '注册时间',
                      '经营状态', '所属区域', '近期是否有工商变更', '变更事项', '匹配方式']

    output_file = 'D:\\software\\Nwt_cache_recv\\刘玉梅\\注册用户数据导出_已填充2.xlsx'
    df_final[output_columns].to_excel(output_file, index=False)
    logger.info(f"数据填充完成！结果已保存至: {output_file}")

    # 10. 保存未匹配的记录用于调试
    unmatched_records = df_final[df_final['匹配方式'] == '未匹配']
    if not unmatched_records.empty:
        unmatched_file = '未匹配记录.xlsx'
        unmatched_records.to_excel(unmatched_file, index=False)
        logger.info(f"未匹配记录已保存至: {unmatched_file}")
        logger.info(f"未匹配记录数量: {len(unmatched_records)}")

    return df_final


if __name__ == "__main__":
    result_df = fill_company_data()