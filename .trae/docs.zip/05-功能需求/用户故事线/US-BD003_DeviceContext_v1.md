---
document_id: "US-BD003-Device"
document_type: "user_story"
document_title: "用户故事线：设备上下文（Device）"
version: "1.0"
status: "draft"
project_id: "P0_Huakuantong"
project_name: "海外智慧建筑P0_华宽通园区智能体"
author: "AI Assistant"
owner: "Product & Architecture"
created_date: "2025-12-16"
file_path: "project-docs/05-functional-requirements/user-stories/US-BD003-Device.md"
tags: ["用户故事", "设备", "LNS接入", "设备注册", "遥测与控制"]
keywords: ["Integration", "DevEUI", "批量导入", "控制日志"]
linked_br_ids: ["BR003"]
---

# 用户故事线：设备上下文（Device）

## 1. 关联关系总表

### 1.1 用户故事与需求关联矩阵

| 用户故事编号 | 用户故事名称 | 关联业务需求 | 关联功能需求 | 关联用户旅程 | 关联领域事件 | 优先级 | 故事点 |
|--------------|--------------|--------------|--------------|--------------|--------------|--------|--------|
| US-201 | LNS接入配置与连通性测试 | BR003 | FR-BD003-LNS | UJM-DEV-CT01 | LNSConfigCreated, LNSConnectionStatusChanged | 高 | 5 |
| US-202 | 设备注册与空间绑定 | BR003 | FR-BD003-REG | UJM-DEV-CT02 | DeviceCreated, DeviceInstalled | 高 | 5 |
| US-203 | 设备生命周期维护与删除 | BR003 | FR-BD003-LIFECYCLE | UJM-DEV-CT03 | DeviceUnassignedFromSpace, DeviceDeleted | 中 | 5 |
| US-204 | 设备展示与批量操作 | BR003 | FR-BD003-LIST | UJM-DEV-CT04 | DeviceListExported, BatchControlExecuted | 中 | 5 |
| US-205 | 设备监看与控制闭环 | BR003 | FR-BD003-CONTROL | UJM-DEV-CT05 | DeviceControlCommandSent | 中 | 5 |

### 1.2 跨文档追溯关系

| 关联类型 | 源文档 | 目标文档 | 关联关系描述 | 关联强度 |
|----------|--------|----------|--------------|----------|
| 实现关系 | US-201 | FR-BD003-LNS | 用户故事通过功能需求实现 | 强 |
| 实现关系 | US-202 | FR-BD003-REG | 用户故事通过功能需求实现 | 强 |
| 来源关系 | US-204 | ES001 | 用户故事来源于空间设备列表视图 | 中 |
| 触发关系 | US-205 | ES001 | 控制指令触发下行日志与Request Update | 强 |
| 满足关系 | US-201~US-205 | BR003 | 用户故事满足BR003设备域能力 | 强 |

## 2. 故事线上下文

### 2.1 业务上下文
- 主要业务域：设备域（BD003）
- 核心流程：LNS接入→设备注册→空间绑定→展示与控制→生命周期
- 业务价值：统一设备资产与数据通道，支撑自动化与洞察

### 2.2 技术上下文
- 关键集成点：ThingsBoard Integration/Converter，MQTT，空间域
- 数据实体：LNSIntegration、Device、DeviceTelemetry、CommandLog

## 3. 详细用户故事

### 3.1 US-201：LNS接入配置与连通性测试
**作为** 建筑管理者  
**我想要** 配置不同厂商的LNS并测试连通性  
**以便于** 打通设备上行与下行的底层链路

验收标准：
- [ ] 给定选择不同厂商时，表单字段差异化展示
- [ ] 给定错误MQTT密码测试返回Fail；正确配置返回Success
- [ ] 给定保存后在TB后台能看到激活的Integration记录

业务规则：
1. 唯一性：禁止相同服务器+Org+App重复配置
2. 超时策略可配置（连接/读写）

### 3.2 US-202：设备注册与空间绑定
**作为** 建筑管理者  
**我想要** 在当前空间页面注册设备并自动建立安装关系  
**以便于** 降低部署复杂度并确保数据归属正确

验收标准：
- [ ] 给定在房间页添加设备后，安装位置显示为当前房间
- [ ] 给定批量导入包含重复SN时，重复数据被标记不可用并需删除后提交
- [ ] 给定选择所属LNS后设备能正常接收解析数据

业务规则：
1. SN/DevEUI全局唯一，批量导入禁止覆盖既有设备
2. 安装位置绑定取决于当前页面上下文的SpaceID

### 3.3 US-203：设备生命周期维护与删除
**作为** 建筑管理者  
**我想要** 维护设备档案并安全地解绑或删除设备  
**以便于** 保证数据一致性与自动化策略安全

验收标准：
- [ ] 给定删除被策略引用设备时提示并自动禁用策略
- [ ] 给定删除有历史数据设备时仅软删除并提供备份导出
- [ ] 给定删除未分配且无历史数据设备时允许物理删除

业务规则：
1. 删除不影响历史能耗统计与报表
2. 解绑后设备状态变更为Unassigned

### 3.4 US-204：设备展示与批量操作
**作为** 用户/管理员  
**我想要** 在空间视角分组查看设备并执行批量操作  
**以便于** 提升管理效率与控制能力

验收标准：
- [ ] 给定勾选“包含子空间设备”，列表增加并显示所属空间列
- [ ] 给定跨类型选择时禁用批量控制，仅保留移动/删除
- [ ] 给定导出数据量过大时自动转异步任务

业务规则：
1. 强制按设备类型分组展示
2. 在线状态与核心遥测近实时更新

### 3.5 US-205：设备监看与控制闭环
**作为** 用户/运维人员  
**我想要** 在设备主页查看全信息并下发指令形成闭环  
**以便于** 提升远程运维效率与可靠性

验收标准：
- [ ] 给定可写遥测支持直接编辑下发并生成控制日志
- [ ] 给定勾选Request Update后，设备应立即上报最新状态
- [ ] 给定温湿度设备主页显示霉菌风险分析，不具备该属性的设备隐藏此模块

业务规则：
1. 指令需带参数说明，记录操作人与时间
2. 自定义仪表盘单设备唯一，保存覆盖旧配置

## 4. 故事线整体验收标准
- [ ] 给定完成US-201~US-205流程，设备接入、注册、展示与控制闭环可用
- [ ] 给定删除/解绑设备，历史报表与自动化安全不受影响

## 5. 数据模型关联

| 用户故事 | 主要数据实体 | 关键属性 | 关联表 |
|----------|--------------|----------|--------|
| US-201 | LNSIntegration | ProviderType, ApiBaseUrl, TbIntegrationID | LNS_CONFIG_TABLE |
| US-202 | Device | SerialNumber, DeviceType, InstallSpaceID | DEVICE_TABLE |
| US-203 | Device, CommandLog | Status, DeletedAt | DEVICE_TABLE, CMD_LOG_TABLE |
| US-204 | DeviceViewPreference | VisibleColumns, FilterConditions | DEVICE_VIEW_PREF_TABLE |
| US-205 | DeviceTelemetry, CommandLog | TelemetryLatest, CommandPayload | TELEMETRY_TABLE, CMD_LOG_TABLE |

