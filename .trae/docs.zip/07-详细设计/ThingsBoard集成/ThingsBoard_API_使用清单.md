# ThingsBoard API 使用清单

## 1. 认证与授权 API

| API路径 | 方法 | 功能描述 | 用途 |
|---------|------|----------|------|
| /api/auth/login | POST | 用户登录 | 获取访问令牌 |
| /api/auth/token | POST | 刷新令牌 | 刷新访问令牌 |
| /api/auth/logout | POST | 用户登出 | 登出并失效令牌 |

## 2. 设备管理 API

| API路径 | 方法 | 功能描述 | 用途 |
|---------|------|----------|------|
| /api/device | POST | 创建设备 | 创建设备记录 |
| /api/device/{deviceId} | GET | 获取设备信息 | 获取设备详情 |
| /api/device/{deviceId} | PUT | 更新设备信息 | 更新设备详情 |
| /api/device/{deviceId} | DELETE | 删除设备 | 删除设备记录 |
| /api/device | GET | 搜索设备 | 批量查询设备 |
| /api/device/count | GET | 设备数量统计 | 统计设备数量 |

## 3. 设备控制 API

| API路径 | 方法 | 功能描述 | 用途 |
|---------|------|----------|------|
| /api/plugins/rpc/{deviceId} | POST | 发送RPC命令 | 向设备下发控制命令 |
| /api/plugins/rpc/{deviceId} | GET | 获取RPC命令结果 | 获取设备命令执行结果 |
| /api/plugins/rpc/oneway/{deviceId} | POST | 发送单向RPC命令 | 向设备下发无需回复的命令 |

## 4. LNS配置相关 API

### 4.1 API调用示例

```bash
curl 'http://172.22.3.105/api/plugins/telemetry/DEVICE/0f7da2b0-e91d-11ef-a8ee-99a8c68f9649/SHARED_SCOPE' \
  -H 'Accept: application/json, text/plain, */*' \
  -H 'Accept-Language: zh-CN,zh;q=0.9' \
  -H 'Cache-Control: no-cache' \
  -H 'Connection: keep-alive' \
  -H 'Content-Type: application/json' \
  -H 'Origin: http://172.22.3.105' \
  -H 'Pragma: no-cache' \
  -H 'Referer: http://172.22.3.105/dashboards/f0e38130-e903-11ef-a8ee-99a8c68f9649?state=W3siaWQiOiJkZWZhdWx0IiwicGFyYW1zIjp7fX0seyJpZCI6ImdhdGV3YXlfZGV0YWlscyIsInBhcmFtcyI6eyJlbnRpdHlJZCI6eyJpZCI6IjBmN2RhMmIwLWU5MWQtMTFlZi1hOGVlLTk5YThjNjhmOTY0OSIsImVudGl0eVR5cGUiOiJERVZJQ0UifSwiZW50aXR5TmFtZSI6IumAmueUqOaOpeWFpee9keWFsyIsImVudGl0eUxhYmVsIjoi6YCa55So5o6l5YWl572R5YWzIn19LHsiaWQiOiJjb25uZWN0b3JzIiwicGFyYW1zIjp7ImVudGl0eUlkIjp7ImVudGl0eVR5cGUiOiJERVZJQ0UiLCJpZCI6IjBmN2RhMmIwLWU5MWQtMTFlZi1hOGVlLTk5YThjNjhmOTY0OSJ9LCJlbnRpdHlOYW1lIjoi6YCa55So5o6l5YWl572R5YWzIiwiZW50aXR5TGFiZWwiOiLpgJrnlKjmjqXlhaXnvZHlhbMifX1d' \
  -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36' \
  -H 'X-Authorization: Bearer YOUR_JWT_TOKEN' \
  --data-raw $'{"OC":{"mode":"advanced","name":"OC","type":"mqtt","enableRemoteLogging":false,"logLevel":"INFO","sendDataOnlyOnChange":false,"configuration":"oc.json","configurationJson":{"broker":{"name":"OC-172_17_201_15","host":"172.17.201.15","port":1883,"clientId":"gw_pLoh7THJzthWrYDLk2mE_2","version":5,"maxMessageNumberPerWorker":10,"maxNumberOfWorkers":100,"sendDataOnlyOnChange":false,"security":{"type":"basic","username":"ed8ea1fdab29484aa8c32a5b4a32ce14","password":"c764b1550c9c4d6bb3bd1f0d0fac581e"}},"mapping":[{"topicFilter":"org/1/project/82/device/001a0103ff000313/dat/up","converter":{"type":"json","deviceNameJsonExpression":"${devEUI}","sendDataOnlyOnChange":false,"timeout":60000,"attributes":[{"key":"project","value":"${project}","type":"string"},{"key":"app","value":"${app}","type":"string"},{"key":"devEui","value":"${devEUI}","type":"string"}],"timeseries":[{"key":"data","value":"${data}","type":"string"},{"key":"body","value":"{\'channel\': \'${channel}', \'ts\': ${ts}, \'fPort\': ${fPort}, \'object\': ${object}, \'downlink_gateway\': \'${downlink_gateway}', \'rssi\': ${rssi}, \'loRaSNR\': ${loRaSNR}, \'rxInfo\': ${rxInfo}}","type":"string"}]}}],"connectRequests":[],"disconnectRequests":[],"attributeRequests":[],"attributeUpdates":[],"serverSideRpc":[{"type":"oneWay","deviceNameFilter":".*","methodFilter":".*","requestTopicExpression":"org/1/device/${deviceName}/down","valueExpression":"${params}"}]},"configVersion":"","ts":1765953336547}}'
```

## API调用示例

### 1. 设备创建示例

**请求：**
```bash
curl -X POST "http://localhost:8080/api/device" \
  -H "X-Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Device-001",
    "type": "temperature-sensor",
    "label": "Temperature Sensor",
    "tenantId": "YOUR_TENANT_ID",
    "customerId": "YOUR_CUSTOMER_ID",
    "deviceProfileId": "YOUR_DEVICE_PROFILE_ID",
    "additionalInfo": {
      "location": "Building 1, Floor 2",
      "model": "TS-100"
    }
  }'
```

**响应：**
```json
{
  "id": {
    "entityType": "DEVICE",
    "id": "DEVICE_ID"
  },
  "createdTime": 1639740000000,
  "name": "Device-001",
  "type": "temperature-sensor",
  "label": "Temperature Sensor",
  "tenantId": {
    "entityType": "TENANT",
    "id": "YOUR_TENANT_ID"
  },
  "customerId": {
    "entityType": "CUSTOMER",
    "id": "YOUR_CUSTOMER_ID"
  },
  "deviceProfileId": {
    "entityType": "DEVICE_PROFILE",
    "id": "YOUR_DEVICE_PROFILE_ID"
  },
  "additionalInfo": {
    "location": "Building 1, Floor 2",
    "model": "TS-100"
  }
}
```

### 2. 发送RPC命令示例

**请求：**
```bash
curl -X POST "http://localhost:8080/api/plugins/rpc/oneway/DEVICE_ID" \
  -H "X-Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "method": "setTemperature",
    "params": {
      "temperature": 22
    }
  }'
```

**响应：**
```json
{
  "id": "RPC_REQUEST_ID",
  "createdTime": 1639740000000,
  "deviceId": {
    "entityType": "DEVICE",
    "id": "DEVICE_ID"
  },
  "method": "setTemperature",
  "params": {
    "temperature": 22
  },
  "status": "QUEUED"
}
```

## 集成建议

1. **使用API封装层**：创建API封装层，统一处理认证、重试、错误处理等逻辑
2. **实现缓存机制**：对频繁访问的设备信息、配置等数据进行缓存
3. **使用异步调用**：对耗时的API调用使用异步方式，提高系统响应性
4. **实现监控与日志**：记录API调用的性能指标和错误信息，便于故障排查
5. **实现限流机制**：对API调用进行限流，防止过度请求导致系统过载
6. **使用消息队列**：对批量操作和异步任务使用消息队列，提高系统可靠性
7. **实现重试策略**：对网络错误等临时性故障实现自动重试机制
8. **保持API版本兼容**：关注ThingsBoard API版本变更，确保兼容性

## 安全建议

1. **保护API令牌**：确保JWT令牌安全存储，避免泄露
2. **使用HTTPS**：在生产环境中使用HTTPS加密API通信
3. **最小权限原则**：为API调用者分配最小必要权限
4. **定期轮换凭证**：定期轮换设备凭证和API密钥
5. **实现IP白名单**：对敏感API实现IP白名单限制
6. **监控异常访问**：监控API调用模式，检测异常访问行为
7. **实现请求签名**：对重要API请求实现签名验证，防止篡改

## 性能优化建议

1. **批量操作**：对多个设备的操作使用批量API，减少请求次数
2. **合理设置时间范围**：查询历史数据时设置合理的时间范围，避免大数据量查询
3. **使用聚合查询**：对历史数据使用聚合查询，减少返回数据量
4. **实现数据缓存**：对频繁访问的数据实现缓存，减少API调用
5. **合理设置超时时间**：根据业务需求设置合理的API超时时间
6. **使用异步处理**：对耗时操作使用异步处理，提高系统吞吐量
7. **优化查询参数**：使用索引字段进行查询，提高查询效率
8. **定期清理数据**：定期清理过期数据，提高系统性能

## 故障排查指南

1. **检查认证信息**：确保JWT令牌有效，未过期
2. **检查API路径和方法**：确保API路径和HTTP方法正确
3. **检查请求参数**：确保请求参数格式正确，必填字段完整
4. **检查权限设置**：确保调用者具有足够的权限
5. **查看系统日志**：检查ThingsBoard系统日志，查找错误信息
6. **检查网络连接**：确保网络连接正常，没有防火墙拦截
7. **检查设备状态**：确保设备在线，能够接收命令
8. **检查规则链配置**：确保规则链配置正确，能够处理数据
9. **检查数据库状态**：确保数据库连接正常，性能良好
10. **检查系统资源**：确保系统资源充足，没有过载

## 版本兼容性

| ThingsBoard版本 | API版本 | 兼容性说明 |
|----------------|---------|------------|
| 3.4.x | v1 | 基础API稳定，部分高级功能可能有变化 |
| 3.5.x | v1 | API稳定，新增部分功能 |
| 3.6.x | v1 | API稳定，优化部分API性能 |
| 3.7.x | v1 | API稳定，新增LNS相关功能 |
| 3.8.x | v1 | API稳定，优化设备管理功能 |

## 结论

本API使用清单涵盖了ThingsBoard平台的核心API，包括认证与授权、设备管理、设备控制和LNS配置相关功能。在集成过程中，建议根据实际业务需求选择合适的API，并遵循安全、性能优化和故障排查建议，确保系统的可靠性、安全性和性能。

随着ThingsBoard平台的不断发展，API可能会有更新和变化，建议关注官方文档和版本发布说明，及时更新API调用方式，确保系统的兼容性和稳定性。