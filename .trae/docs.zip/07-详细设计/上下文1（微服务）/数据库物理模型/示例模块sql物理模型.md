```markdown
---
document_id: "DB-PHY-001"
document_type: "physical_model_ddl"
document_title: "数据库物理模型DDL文档模板"
version: "1.0"
status: "draft"
project_id: "P001"
detailed_design: "DD001"
author: "系统架构师"
owner: "数据库管理员"
created_date: "2024-01-30"
file_path: "project-docs/08-physical-model/DB-PHY-001-DDL-Template.md"
tags: ["DDL", "物理模型", "SQL", "数据库"]
keywords: ["建表语句", "索引", "存储过程", "数据库设计"]
database_type: "MySQL"  # 可选值：MySQL、PostgreSQL、Oracle、SQL Server、MongoDB等
---
```

# 数据库物理模型DDL文档

## 一、数据库对象清单总览

| 对象类型 | 对象名称（英文） | 对象名称（中文） | 所属库/模式 | 详细设计ID | 主键字段 | 索引数量 | 触发器数量 | 备注 |
| -------- | ---------------- | ---------------- | ----------- | ---------- | -------- | -------- | ---------- | ---- |
| 表       |                  |                  |             |            |          |          |            |      |
| 索引     |                  |                  |             |            | -        | -        | -          |      |
| 视图     |                  |                  |             |            | -        | -        | -          |      |
| 存储过程 |                  |                  |             |            | -        | -        | -          |      |
| 触发器   |                  |                  |             |            | -        | -        | -          |      |
| 函数     |                  |                  |             |            | -        | -        | -          |      |
| 序列     |                  |                  |             |            | -        | -        | -          |      |

**注**：
- 对象类型包括：表(Table)、索引(Index)、视图(View)、存储过程(Stored Procedure)、触发器(Trigger)、函数(Function)、序列(Sequence)

- 对于非表对象，"主键字段"、"索引数量"、"触发器数量"列填写"-"或不填。

  ## 二、DDL语句详述

  ### 2.1 建表语句（Table DDL）

  - 表名：{表名英文}
  - 中文说明：{表名中文}

  ```sql
  CREATE TABLE {库名}.{表名英文} (
      {字段名1} {数据类型} {约束},
      {字段名2} {数据类型} {约束},
      ...
      PRIMARY KEY ({主键字段}),
      INDEX {索引名} ({字段}),
      ...
  ) COMMENT = '{表注释}';

### 2.2 索引创建语句（Index DDL）

索引名称：{索引名}

所属表：{表名英文}

索引类型：{普通索引/唯一索引/全文索引}
```sql
CREATE {UNIQUE|FULLTEXT} INDEX {索引名} 
ON {库名}.{表名英文} ({字段1}, {字段2}, ...);
```

### 2.3 存储过程（Stored Procedure）

存储过程名称：{过程名英文}
功能说明：{中文说明}

```sql
CREATE PROCEDURE {库名}.{过程名英文} (
    IN {参数1} {类型},
    OUT {参数2} {类型}
)
BEGIN
    -- 存储过程逻辑
END;
```

### 2.4 视图（View）

视图名称：{视图名英文}
功能说明：{中文说明}

```sql
CREATE VIEW {库名}.{视图名英文} AS
SELECT {字段列表}
FROM {表名}
WHERE {条件};
```

### 2.5 触发器（Trigger）

触发器名称：{触发器名英文}
触发时机：{BEFORE/AFTER} {INSERT/UPDATE/DELETE}

```sql
CREATE TRIGGER {触发器名英文}
{BEFORE|AFTER} {INSERT|UPDATE|DELETE} ON {表名英文}
FOR EACH ROW
BEGIN
    -- 触发器逻辑
END;
```

## 三、数据初始化脚本

### 3.1 基础数据插入

```sql
-- 初始化说明：系统运行必需的基础数据

-- 示例：用户角色表初始化
INSERT INTO {库名}.{角色表名} (role_id, role_name, role_code, status, create_time) VALUES
(1, '管理员', 'ADMIN', 1, NOW()),
(2, '普通用户', 'USER', 1, NOW()),
(3, '访客', 'GUEST', 1, NOW());

-- 示例：系统配置表初始化
INSERT INTO {库名}.{配置表名} (config_key, config_value, config_desc, create_time) VALUES
('system.version', '1.0.0', '系统版本', NOW()),
('system.timeout', '1800', '会话超时时间(秒)', NOW()),
('system.upload_limit', '10485760', '文件上传大小限制(字节)', NOW());

-- 示例：菜单权限表初始化
INSERT INTO {库名}.{菜单表名} (menu_id, parent_id, menu_name, menu_code, menu_type, sort_order, create_time) VALUES
(1, 0, '系统管理', 'sys', 'DIRECTORY', 1, NOW()),
(2, 1, '用户管理', 'user', 'MENU', 1, NOW()),
(3, 1, '角色管理', 'role', 'MENU', 2, NOW());
```

### 3.2 测试数据插入（开发/测试环境使用）

```sql
-- 初始化说明：用于开发和测试环境的测试数据

-- 示例：测试用户数据
INSERT INTO {库名}.{用户表名} (user_id, username, password, email, phone, status, create_time) VALUES
(10001, 'admin', '加密密码', 'admin@example.com', '13800138000', 1, NOW()),
(10002, 'test01', '加密密码', 'test01@example.com', '13800138001', 1, NOW()),
(10003, 'test02', '加密密码', 'test02@example.com', '13800138002', 1, NOW());

-- 示例：测试部门数据
INSERT INTO {库名}.{部门表名} (dept_id, dept_name, parent_id, sort_order, create_time) VALUES
(1, '总公司', 0, 1, NOW()),
(2, '技术部', 1, 1, NOW()),
(3, '市场部', 1, 2, NOW());
```

### 3.3 数据初始化脚本说明

| 脚本类型     | 执行环境      | 执行顺序 | 备注                   |
| ------------ | ------------- | -------- | ---------------------- |
| 基础数据     | 所有环境      | 1        | 系统运行必需的基础数据 |
| 测试数据     | 开发/测试环境 | 2        | 仅用于开发和测试环境   |
| 历史数据迁移 | 生产环境      | 3        | 从旧系统迁移的历史数据 |



## 
